/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employeedemo;

import common.EntityOperations;
import Employee.EmployeeOperations;
import java.util.Scanner;

/**
 *
 * @author naresh5
 */
public class EmployeeDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int userChoice, totalEmployees;
        try {
            Scanner scanner = new Scanner(System.in);
            System.out.print("\nEnter Size Of Employees : ");
            totalEmployees = scanner.nextInt();
            if (totalEmployees <= 0) {
                System.out.println("Size Of Employee Size Must Be Greter than zero(0)..!!! Please Try Again.");
                return;
            }
            EntityOperations operations = new EmployeeOperations(totalEmployees);
            System.out.println("------------------- Employee Management System ------------------");

            for (;;) {
                System.out.println("\n1:Add Employee");
                System.out.println("2:Update Employee");
                System.out.println("3:Delete Employee");
                System.out.println("4:Show Employees");
                System.out.println("5:Exit");
                System.out.print("\nEnter Your Choice : ");
                userChoice = scanner.nextInt();
                try {
                    switch (userChoice) {
                        case 1:
                            operations.add();
                            break;
                        case 2:
                            operations.update();
                            break;
                        case 3:
                            operations.delete();
                            break;
                        case 4:
                            operations.showList();
                            break;
                        case 5:
                            System.out.println("\nThanks For Using Bye..\n");
                            return;
                        default:
                            System.out.println("Invalid  Choice Try Again..");
                    }
                } catch (Exception e) {
                    System.out.println("\nOperation Unsuccessfully Done.,\nBecause Exception Arrised : " + e);
                }
            }
        } catch (Exception ex) {
            System.out.println("Ecxeption : " + ex);
        }
    }

}
