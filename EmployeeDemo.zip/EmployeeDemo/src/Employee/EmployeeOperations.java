/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Employee;

import common.EntityOperations;
import common.ManageOperations;
import java.util.Scanner;

/**
 *
 * @author naresh5
 */

//THIS CLASS IS USED FOR SETTING  ENTITY DATA FOR OPERATION LIKE(ADD DATA,UPDATE DATA,ID FOR DELETE DATA)
public class EmployeeOperations implements EntityOperations {

    //INTERFACE REFERENCE VARIABLE CREATED FOR ABSTRACTION OF IMPLEMENTION
    private final ManageOperations manageOperations;

    public EmployeeOperations(int totalEmployees) {
        
        //CREATE THE OBJECT OF ManageEmployees TYPE AND ASSIGN TO ManageOperations TYPE BECAUSE ManageEmployees IT IMPLEMENTS ManageOperations
        this.manageOperations = new ManageEmployees(totalEmployees);
    }

    public Employee setEmployeeData(int employeeId) {
        String name, department, designation;
        double salary;
        Scanner scanner = new Scanner(System.in);
        if (employeeId == 0) {
            System.out.print("Enter Employee Id : ");
            employeeId = Integer.parseInt(scanner.nextLine());
        }
        System.out.print("Enter Employee Name : ");
        name = scanner.nextLine();
        System.out.print("Enter Employee Department : ");
        department = scanner.nextLine();
        System.out.print("Enter Employee Designation : ");
        designation = scanner.nextLine();
        System.out.print("Enter Employee Salary : ");
        salary = Double.parseDouble(scanner.nextLine());
        Employee employee = new Employee(employeeId, name, salary, department, designation);
        return employee;
    }

    //throws Exception IS USED BECUASE IF Exception ARRISE THEN IT throws TO CALLING PROGRAM(EMPLOYEE DEMO CLASS) AND HANDLE THRE
    @Override
    public void add() throws Exception {
        this.manageOperations.add(setEmployeeData(0));
        System.out.println("\nEmployee Added Successfully...!!!");
    }

    @Override
    public void update() throws Exception {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Employee Id : ");
        int employeeId = scanner.nextInt();
        if (this.manageOperations.getSingleObject(employeeId) != null) {
            this.manageOperations.update(setEmployeeData(employeeId), employeeId);
            System.out.println("\nEmployee Updated Successfully...!!!");
        } else {
            System.out.println("\nEmployee Not Found For This ID : " + employeeId + "\n");
        }
    }

    @Override
    public void delete() throws Exception {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Employee Id : ");
        int employeeId = scanner.nextInt();
        if (this.manageOperations.getSingleObject(employeeId) != null) {
            this.manageOperations.delete(employeeId);
            System.out.println("\nEmployee Deleted Successfully...!!!");
        } else {
            System.out.println("\nEmployee Not Found For This ID : " + employeeId + "\n");
        }
    }

    @Override
    public void showList() throws Exception {
        this.manageOperations.showList();
    }

}
