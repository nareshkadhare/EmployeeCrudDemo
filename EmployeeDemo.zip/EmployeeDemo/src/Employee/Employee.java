/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Employee;

/**
 *
 * @author naresh5
 */

//THIS IS KNOWN AS POJO CLASS(plain old java object)
public class Employee {
    
    //Encapsulation Done here
    //Make All the fields as private and provide required fields as Property(GETTER/SETTER)
    private int id;
    private String name;
    private double salary;
    private String department;
    private String designation;

    //FOR SETTING ALL FIELDS
    public Employee(int id, String name, double salary, String department, String designation) {
        this.id = id;
        this.name = name;
        this.salary = salary;
        this.department = department;
        this.designation = designation;
    }

    //FOR PRITING EMPLOYEE OBJECT
    @Override
    public String toString() {
        return "Employee{" + "id=" + id + ", name=" + name + ", salary=" + salary + ", department=" + department + ", designation=" + designation + '}';
    }
    
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }
    
    
}
