/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Employee;

import common.ManageOperations;

/**
 *
 * @author naresh5
 */
public class ManageEmployees implements ManageOperations {

    private Employee employeeList[];

    public static int counter;

    {
        counter = 0;
    }

    public ManageEmployees(int employeeSize) {
        this.employeeList = new Employee[employeeSize];
    }

    public Employee[] getEmployeeList() {
        return employeeList;
    }

    public void setEmployeeList(Employee[] employeeList) {
        this.employeeList = employeeList;
    }

    @Override
    public void add(Object object) throws Exception {
        try {
            if (employeeList.length == counter) {
                throw new Exception("\nCant Insert Into Employeee List , Because it is full now.");
            } else {
                this.employeeList[counter++] = (Employee) object;
            }
        } catch (Exception ex) {
            counter--;
            throw new Exception(ex);
        }
    }

    @Override
    public void update(Object object, int id) throws Exception {
        if (counter == 0) {
            System.out.println("\nNO EMPLOYEES FOUND...!!!\n");
            return;
        }
        for (int i = 0; i < counter; i++) {
            if (this.employeeList[i].getId() == id) {
                this.employeeList[i] = (Employee) object;
                break;
            }
        }
    }

    @Override
    public void delete(int id) throws Exception {
        if (counter == 0) {
            System.out.println("\nNO EMPLOYEES FOUND...!!!\n");
            return;
        }
        int j = 0;
        for (int i = 0; i < counter; i++) {
            if (this.employeeList[i].getId() == id) {
                for (j = i; j < counter - 1; j++) {
                    this.employeeList[j] = this.employeeList[j + 1];
                }
                this.employeeList[j] = null;
                break;
            }
        }
        counter--;
    }

    @Override
    public void showList() throws Exception {
        if (counter == 0) {
            System.out.println("\nNO EMPLOYEES FOUND...!!!\n");
            return;
        }
        for (int i = 0; i < counter; i++) {
            System.out.println("\n" + this.employeeList[i] + "\n");
        }
    }

    @Override
    public Object getSingleObject(int id) throws Exception {
        for (int i = 0; i < counter; i++) {
            if (this.employeeList[i].getId() == id) {
                return this.employeeList[i];
            }
        }
        return null;
    }

}
