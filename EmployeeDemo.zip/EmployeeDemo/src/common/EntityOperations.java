/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package common;

/**
 *
 * @author naresh5
 */

//For Providing Common Operation Structure
//IT IS ALSO KNOWN AS POJI
public interface EntityOperations {
    void add() throws Exception;
    void update() throws Exception;
    void delete() throws Exception;
    void showList() throws Exception;
}
